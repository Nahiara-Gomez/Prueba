/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaLogica;

/**
 *
 * @author nahue
 */
public class Persona {
  private String CIx;
  private String Nombrex;
  private String NombreA;
  private String Apellidox;

    public String getCI() {
        return CIx;
    }
    
    public void setCI(String CI) {
        this.CIx = CI;
    }

    public String getNombre() {
        return Nombrex;
    }

    public void setNombre(String Nombrex) {
        this.Nombrex = Nombrex;
    }

    public String getApellido() {
        return Apellidox;
    }

    public void setApellido(String Apellidox) {
        this.Apellidox = Apellidox;
    }

    public String getNombreA() {
        return NombreA;
    }

    public void setNombreA(String NombreA) {
        this.NombreA = NombreA;
    }
    
 
   public void mostrar_informacion() {
       System.out.print("CI"+ CIx);
       System.out.print("Nombre"+ Nombrex);
       System.out.print("Apellido"+ Apellidox);
               }

}

