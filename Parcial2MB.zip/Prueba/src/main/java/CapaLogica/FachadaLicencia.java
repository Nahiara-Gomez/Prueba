/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaLogica;

import java.sql.SQLException;

import CapaExepcion.BDException;
import CapaPersistencias.GuardarLicencia;
import java.util.List;
/**
 *
 * @author DELL
 */
public class FachadaLicencia {  
    
    public void LicenciasGuardar(Persona per, Docente doc, Licencias lic)throws Exception, BDException, SQLException{
        GuardarLicencia gua= new GuardarLicencia();
        gua.LicenciasGuardar(per,doc,lic);
   
    }
  
     public List<Licencias> buscarPorTurno(String turno) throws Exception, BDException, SQLException {
       GuardarLicencia gua= new GuardarLicencia();
         return gua.buscarPorTurno(turno);
    }
   public boolean iniciarSesion(String nombre, String IDa) throws Exception{
        GuardarLicencia pers= new GuardarLicencia();
        return  pers.iniciaSesion(nombre,IDa);
    }
    
    public void eliminarLicencia(String CIx) throws Exception, BDException, SQLException {
    GuardarLicencia lice = new GuardarLicencia();
    lice.eliminarLicencia(CIx);
}

public  List<Licencias> mostrarTodas() throws Exception, BDException, SQLException {
   GuardarLicencia lice = new GuardarLicencia();
   return lice.mostrarTodas();
     
}

}
