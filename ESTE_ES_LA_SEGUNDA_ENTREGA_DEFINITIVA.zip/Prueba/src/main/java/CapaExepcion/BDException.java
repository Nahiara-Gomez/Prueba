/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaExepcion;

import java.sql.SQLException;
/**
 *
 * @author nahue
 */


public class BDException extends Exception {

    public BDException(String message) {
        super(message);
    }
    
}
