/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaLogica;

/**
 *
 * @author nahue
 */
public class Alumnos extends Persona {

    public Alumnos(String CI, String nombre, String apellido) {
        super(CI, nombre, apellido);
    }
    
}
