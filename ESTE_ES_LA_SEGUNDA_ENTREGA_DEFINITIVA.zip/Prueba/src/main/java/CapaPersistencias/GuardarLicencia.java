/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaPersistencias;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import CapaExepcion.BDException;
import CapaLogica.Docente;
import CapaLogica.Licencias;

/**
 *
 * @author Alumno
 */
public class GuardarLicencia {
    
    // Sentencia para guardar una licencia
    private static final String SQL_Guardar = (
        "INSERT INTO parcial.licencias(CIL, FechaINI, FechaFIN, Motivo) VALUES (?,?,?,?)"
    );
    private static final String SQL_Guardar2 =
    "INSERT INTO parcial.docentes(CId, Materia, Grupo, Turno) VALUES (?,?,?)";
    
    // Consulta simple por CI
   private static final String SQL_Consulta_Licencias = (
   "SELECT u.Nombre, u.Apellido, d.Turno, e.CursoE AS Curso, " +
   "l.FechaINI, l.FechaFIN, l.Motivo AS Licencia " +
    "FROM parcial.usuarios u " +
    "JOIN parcial.docentes d ON u.CI = d.CId " +
    "JOIN parcial.enseña e ON u.CI = e.CIE " +
    "JOIN parcial.licencias l ON u.CI = l.CI " +
    "WHERE d.Grupo = ?"
                                                );

    
    // Atributos de conexión
    public Conexion cone = new Conexion();
    public PreparedStatement ps;
    public ResultSet rs;
    
    // Método para guardar una licencia
    public void guardarLicencia(Licencias lic) throws Exception, SQLException {
        try {
            int resultado = 0;
            Connection con = cone.getConnection();
            ps = (PreparedStatement) con.prepareStatement(SQL_Guardar);
            ps.setString(1, lic.getCI());
            ps.setString(2, lic.getFechaINI()); 
            ps.setString(3, lic.getFechaFIN());
            ps.setString(4, lic.getMotivo());
            
            resultado = ps.executeUpdate();
            
        } catch (SQLException e) {
            throw new Exception("Tuve un problemita con la base al guardar la licencia");
        }
    }
    public void guardarDocente(Docente doc) throws Exception, SQLException {
        try {
            int resultado = 0;
            Connection con = cone.getConnection();
            ps = (PreparedStatement) con.prepareStatement(SQL_Guardar2);
            ps.setString(1, doc.getCI());
            ps.setString(2, doc.getGrupo()); 
            ps.setString(3, doc.getTurno());
            ps.setString(4, doc.getMateria());
            ps.setString(5, doc.getNombre());
            ps.setString(6, doc.getApellido());
            
            resultado = ps.executeUpdate();
            
        } catch (SQLException e) {
            throw new Exception("Tuve un problemita con la base al guardar la licencia");
        }
    }
//    Método para buscar una licencia por CI
  public Licencias buscarCI(String CI) throws Exception, BDException, SQLException {
      Licencias lic=new Licencias();
        try {
            Connection con = cone.getConnection();
            ps = (PreparedStatement) con.prepareStatement(SQL_Consulta_Licencias);            ps.setString(1, CI);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                String ci = rs.getString("CI");
                String fechaIni = rs.getString("FechaINI");
                String fechaFin = rs.getString("FechaFIN");
                String motivo = rs.getString("Motivo");
                
                lic.setCI(ci);
                lic.setFechaINI(fechaIni);
                lic.setFechaFIN(fechaFin);
                lic.setMotivo(motivo);
            } else {
                throw new Exception("La licencia no está ingresada");
            }
          
       } catch (Exception e) {
         System.out.println(e);
         throw new Exception("No pude obtener la licencia");
       }
       return lic;
 }
}

