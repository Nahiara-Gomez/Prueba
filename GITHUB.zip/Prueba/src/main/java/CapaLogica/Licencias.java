/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaLogica;

/**
 *
 * @author nahue
 */
public class Licencias extends Docente {
    private String fecha_ini;
    private String fecha_fin;
    private String motivo;

    public Licencias(String fecha_ini, String fecha_fin, String motivo, String turno, String grupo, String materia, String CI, String nombre, String apellido) {
        super(turno, grupo, materia, CI, nombre, apellido);
        this.fecha_ini = fecha_ini;
        this.fecha_fin = fecha_fin;
        this.motivo = motivo;
        
    }

    
   

    public Licencias(String turno, String grupo, String materia, String CI, String nombre, String apellido) {
        super(turno, grupo, materia, CI, nombre, apellido);
    }
   

      public String getFecha_ini() {
    return fecha_ini;
}
    public void setFecha_ini(String fecha_ini) {
        this.fecha_ini = fecha_ini;
    }

    public String getFecha_fin() {
        return fecha_fin;
    }

    public void setFecha_fin(String fecha_fin) {
        this.fecha_fin = fecha_fin;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }
public void mostrarLicencia() {
    System.out.print("Fecha de Inicio"+ fecha_ini);
    System.out.print("Fecha de Finalizacion"+ fecha_fin);
    System.out.print("Motivo de la Licencia"+ motivo);
}

  
    
}