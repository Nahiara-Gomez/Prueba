/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaLogica;

/**
 *
 * @author nahue
 */
public class Docente extends Persona {
    String turno;
    private String grupo;
    private String materia;

    public Docente(String turno, String grupo, String materia, String CI, String nombre, String apellido) {
        super(CI, nombre, apellido);
        this.turno = turno;
        this.grupo = grupo;
        this.materia = materia;
    }



    

    

    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public String getMateria() {
        return materia;
    }

    public void setMateria(String materia) {
        this.materia = materia;
    }

}
