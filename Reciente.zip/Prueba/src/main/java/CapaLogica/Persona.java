/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaLogica;

/**
 *
 * @author nahue
 */
public class Persona {
  private String CI;
  private String nombre;
  private String apellido;

    public String getCI() {
        return CI;
    }
public Persona() {
        //TODO Auto-generated constructor stub
    }
    public void setCI(String CI) {
        this.CI = CI;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
 
   public void mostrar_informacion() {
       System.out.print("CI"+ CI);
       System.out.print("Nombre"+ nombre);
       System.out.print("Apellido"+ apellido);
               }

}

