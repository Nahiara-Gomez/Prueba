/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaLogica;

import CapaExepcion.BDException;
import CapaPersistencias.GuardarLicencia;
import java.sql.SQLException;
/**
 *
 * @author DELL
 */
public class FachadaLicencia {
    public void guardarLicencias(Licencias lic)throws Exception{
        GuardarLicencia gua= new GuardarLicencia();
       gua.guardarLicencia(lic);
    }
   public Persona  buscarporCi(String CI) throws  Exception, BDException,SQLException{
       Licencias lic = new Licencias();
       GuardarLicencia lice= new GuardarLicencia();
       lic=lice.buscarCI(CI);
       return lic;
   }
    
}
