/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaPersistencias;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import CapaExepcion.BDException;
import CapaLogica.Docente;
import CapaLogica.Licencias;
import CapaLogica.Persona;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author Alumno
 */
public class GuardarLicencia {
    
    // Sentencia para guardar una licencia
    private static final String SQL_Guardar=("INSERT INTO parcial.inasistencias (Nombrex, Apellidox, CIx, Turnox, FechaInix, FechaFinx, Motivox) " +
        "VALUES (?, ?, ?, ?, ?, ?, ?)");
    
    
  
    
    
    // Consulta simple por Turno
   private static final String SQL_Consulta_Licencias = ("SELECT * FROM inasistencias WHERE UPPER(Turnox) LIKE UPPER(?)");

   
  private static final String SQL_Inicio = ( 
    "SELECT * FROM parcial.administradores A " +
    "INNER JOIN parcial.usuarios U ON A.CIa = U.CI " +
    "WHERE U.NombreA = ? AND A.IDa = ?");

private static final String SQL_Eliminar_Licencia = "DELETE FROM inasistencias WHERE CIx = ?";
     
private static final String SQL_Consulta_Todas_Licencias = 
    "SELECT * FROM inasistencias;";
   
    // Atributos de conexión
    public Conexion cone = new Conexion();
    public PreparedStatement ps;
    public ResultSet rs;

  
public List<Licencias> mostrarTodas() throws Exception, BDException, SQLException {
    
    List<Licencias> lista = new ArrayList<>();

    try {
        Connection con = cone.getConnection();
        ps = (PreparedStatement) con.prepareStatement(SQL_Consulta_Todas_Licencias);
        rs = ps.executeQuery();

        while (rs.next()) {
            Licencias lic = new Licencias();
            lic.setNombre(rs.getString("Nombrex"));     
            lic.setApellido(rs.getString("Apellidox")); 
            lic.setCI(rs.getString("CIx"));             
            lic.setTurno(rs.getString("Turnox"));      
            lic.setFechaINI(rs.getDate("FechaInix"));   
            lic.setFechaFin(rs.getDate("FechaFinx"));
            lic.setMotivo(rs.getString("Motivox"));

            lista.add(lic);
       

    }
        con.close();
    }catch (Exception e) {
        System.out.println(e);
        throw new Exception("No se pudo obtener la licencia por turno.");
    }
    
    return lista;
}




    public void LicenciasGuardar(Persona per, Docente doc, Licencias lic) throws Exception, BDException, SQLException { 

        try{      
        int resultado = 0;
        Connection con = cone.getConnection();
        ps = (PreparedStatement) con.prepareStatement(SQL_Guardar);
       
        ps.setString(1, per.getNombre());
        ps.setString(2, per.getApellido());
        ps.setString(3, per.getCI());
        ps.setString(4, doc.getTurnoX());
        ps.setDate(5, lic.getFechaINI());
        ps.setDate(6, lic.getFechaFin());
        ps.setString(7, lic.getMotivo());
        
        resultado = ps.executeUpdate();
         

       
        } catch (SQLException e) {

            throw new Exception("Tuve un problemita en la base"+e.getMessage());

        }
    
}
    

  


 public List<Licencias> buscarPorTurno(String turno) throws Exception, SQLException {
    List<Licencias> lista = new ArrayList<>();

    try {
        Connection con = cone.getConnection();
        ps = (PreparedStatement) con.prepareStatement (SQL_Consulta_Licencias);
        ps.setString(1, "%" + turno + "%");
        rs = ps.executeQuery();

        while (rs.next()) {
            Licencias lic = new Licencias();
            lic.setNombre(rs.getString("Nombrex"));
            lic.setApellido(rs.getString("Apellidox"));
            lic.setCI(rs.getString("CIx"));
            lic.setTurno(rs.getString("Turnox"));
            lic.setFechaINI(rs.getDate("FechaInix"));
            lic.setFechaFin(rs.getDate("FechaFinx"));
            lic.setMotivo(rs.getString("Motivox"));
            lista.add(lic);
        }

    } catch (SQLException e) {
        throw new SQLException("Error al buscar licencias por turno", e);
    }

    return lista;
}
   
  public boolean iniciaSesion(String nombre, String IDa) throws Exception{
        boolean valido=false;
        
        try{
            Connection con=cone.getConnection();
             ps=con.prepareStatement(SQL_Inicio);
            ps.setString(1,nombre);
            ps.setString(2,IDa);
            rs= ps.executeQuery();
            if(rs.next()){
                valido=true;
            }
            con.close();
        } catch(SQLException e){
            throw new Exception("Error al iniciar sesion " + e.getMessage());
            }
        return valido;
    }
    public void eliminarLicencia(String CIx) throws Exception, BDException, SQLException {
    try {
        Connection con = cone.getConnection();
        ps = (PreparedStatement) con.prepareStatement("DELETE FROM inasistencias WHERE CIx = ?");
        ps.setString(1, CIx);

        int filasAfectadas = ps.executeUpdate();

        if (filasAfectadas == 0) {
            throw new Exception("No se encontró ninguna licencia con esa CI para eliminar.");
        }

    } catch (Exception e) {
        System.out.println(e);
        throw new Exception("No se pudo eliminar la licencia.");
    }
}
}

