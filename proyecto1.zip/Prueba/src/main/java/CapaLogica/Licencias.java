/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaLogica;

/**
 *
 * @author nahue
 */
public class Licencias extends Docente {
    private String fechaINI;
    private String fechaFIN;
    private String motivo;
    

 

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }
public void mostrarLicencia() {
    System.out.print("Fecha de Inicio"+ fechaINI);
    System.out.print("Fecha de Finalizacion"+ fechaFIN);
    System.out.print("Motivo de la Licencia"+ motivo);
}

    public String getFechaINI() {
        return fechaINI;
    }

    public void setFechaINI(String fechaINI) {
        this.fechaINI = fechaINI;
    }

    public String getFechaFIN() {
        return fechaFIN;
    }

    public void setFechaFIN(String fechaFIN) {
        this.fechaFIN = fechaFIN;
    }

  
    
}