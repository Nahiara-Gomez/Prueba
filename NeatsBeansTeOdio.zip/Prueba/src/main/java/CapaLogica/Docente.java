/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaLogica;

/**
 *
 * @author nahue
 */
public class Docente extends Persona {
    private String Turnox;
    private String Grupox;
    private String Materia;

    public String getTurnoX() {
        return Turnox;
    }

    public void setTurno(String Turnox) {
        this.Turnox = Turnox;
    }

    public String Grupox() {
        return Grupox;
    }

    public void Grupox(String Grupox) {
        this.Grupox = Grupox;
    }

    public String getMateria() {
        return Materia;
    }

    public void setMateria(String Materia) {
        this.Materia = Materia;
    }
   


   

}
