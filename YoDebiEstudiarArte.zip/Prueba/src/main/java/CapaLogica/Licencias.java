/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaLogica;

import java.sql.Date;

/**
 *
 * @author nahue
 */
public class Licencias extends Docente {
    private String IDfaltax;
   private java.sql.Date FechaInix;
   private java.sql.Date FechaFinx;
    private String Motivox;
    
    public java.sql.Date getFechaINI() { 
        return FechaInix; }

    public void setFechaINI(java.sql.Date FechaInix) {
        this.FechaInix = FechaInix;
    }
    
     public java.sql.Date getFechaFin() { 
        return FechaFinx; }

    public void setFechaFin(java.sql.Date FechaFinx) {
        this.FechaFinx = FechaFinx;
    }
    


    public String getMotivo() {
        return Motivox;
    }

    public void setMotivo(String Motivox) {
        this.Motivox = Motivox;
    }    
    
    
    public void mostrarLicencia() {
    System.out.print("Fecha de Inicio"+ FechaInix);
    System.out.print("Fecha de Finalizacion"+ FechaFinx);
    System.out.print("Motivo de la Licencia"+ Motivox);
    }
    
    public String getIDfaltax() {
        return IDfaltax;
    }

    public void setIDfaltax(String iDfaltax) {
        IDfaltax = iDfaltax;
    }

  
    
}