/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaLogica;

import java.sql.SQLException;

import CapaExepcion.BDException;
import CapaPersistencias.GuardarLicencia;
/**
 *
 * @author DELL
 */
public class FachadaLicencia {  
    
    public void LicenciasGuardar(Persona per, Docente doc, Licencias lic)throws Exception, BDException, SQLException{
        GuardarLicencia gua= new GuardarLicencia();
        gua.LicenciasGuardar(per,doc,lic);
   
    }
  
    public Persona  buscarPorTurno(String turno) throws  Exception, BDException,SQLException{
       Licencias lic = new Licencias();
       GuardarLicencia lice= new GuardarLicencia();
       lic=lice.buscarPorTurno(turno);
       return lic;
   }
 
   public boolean iniciarSesion(String nombre, String IDa) throws Exception{
        GuardarLicencia pers= new GuardarLicencia();
        return  pers.iniciaSesion(nombre,IDa);
    }
    
    public void eliminarLicencia(int IDfaltax) throws Exception, BDException, SQLException {
    GuardarLicencia lice = new GuardarLicencia();
    lice.eliminarLicencia(IDfaltax);
}

}
