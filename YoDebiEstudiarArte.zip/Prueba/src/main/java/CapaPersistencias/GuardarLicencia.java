/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaPersistencias;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import CapaExepcion.BDException;
import CapaLogica.Admin;
import CapaLogica.Docente;
import CapaLogica.Licencias;
import CapaLogica.Persona;

/**
 *
 * @author Alumno
 */
public class GuardarLicencia {
    
    // Sentencia para guardar una licencia
    private static final String SQL_Guardar=("INSERT INTO parcial.inasistencias (Nombrex, Apellidox, CIx, Turnox, FechaInix, FechaFinx, Motivox) " +
        "VALUES (?, ?, ?, ?, ?, ?, ?)");
    
    
  
    
    
    // Consulta simple por CI
   private static final String SQL_Consulta_Licencias = ("SELECT * FROM inasistencias WHERE Turnox = ?;");

   
  private static final String SQL_Inicio = ( 
    "SELECT * FROM parcial.administradores A " +
    "INNER JOIN parcial.usuarios U ON A.CIa = U.CI " +
    "WHERE U.NombreA = ? AND A.IDa = ?");

private static final String SQL_Eliminar_Licencia = "DELETE FROM inasistencias WHERE IDfaltax = ?";
     
    // Atributos de conexión
    public Conexion cone = new Conexion();
    public PreparedStatement ps;
    public ResultSet rs;

  
public void LicenciasGuardar(Persona per, Docente doc, Licencias lic) throws Exception, BDException, SQLException { 

        try{      
        int resultado = 0;
        Connection con = cone.getConnection();
        ps = (PreparedStatement) con.prepareStatement(SQL_Guardar);
       
        ps.setString(1, per.getNombre());
        ps.setString(2, per.getApellido());
        ps.setString(3, per.getCI());
        ps.setString(4, doc.getTurnoX());
        ps.setDate(5, lic.getFechaINI());
        ps.setDate(6, lic.getFechaFin());
        ps.setString(7, lic.getMotivo());
        
        resultado = ps.executeUpdate();
         

       
        } catch (SQLException e) {

            throw new Exception("Tuve un problemita en la base"+e.getMessage());

        }
    
}
    

  


  public Licencias buscarPorTurno(String turno) throws Exception, BDException, SQLException {
    Licencias lic = new Licencias();
    
    try {
        Connection con = cone.getConnection();
        ps = (PreparedStatement) con.prepareStatement("SELECT * FROM inasistencias WHERE Turnox = ?");
        ps.setString(1, turno);
        rs = ps.executeQuery();
        
        if (rs.next()) {
            String nombre = rs.getString("Nombrex");
            String apellido = rs.getString("Apellidox");
            String cl = rs.getString("Clx");
            String turnox = rs.getString("Turnox");
            String fechaIni = rs.getString("FechaInix");
            String fechaFin = rs.getString("FechaFinx");
            String motivo = rs.getString("Motivox");
            
            lic.setNombre(nombre);
            lic.setApellido(apellido);
            lic.setCI(cl);
            lic.setTurno(turnox);
//            lic.setFechaINI(fechaIni);
//            lic.setFechaFin(fechaFin); ESTO DA ERROR AAAAAAAAAAAAAA JAVA PEDORRO
            lic.setMotivo(motivo);
        } else {
            throw new Exception("No se encontró ninguna licencia para el turno indicado.");
        }

    } catch (Exception e) {
        System.out.println(e);
        throw new Exception("No se pudo obtener la licencia por turno.");
    }
    
    return lic;
}

  public boolean iniciaSesion(String nombre, String IDa) throws Exception{
        boolean valido=false;
        
        try{
            Connection con=cone.getConnection();
             ps=con.prepareStatement(SQL_Inicio);
            ps.setString(1,nombre);
            ps.setString(2,IDa);
            rs= ps.executeQuery();
            if(rs.next()){
                valido=true;
            }
            con.close();
        } catch(SQLException e){
            throw new Exception("Error al iniciar sesion " + e.getMessage());
            }
        return valido;
    }
    public void eliminarLicencia(int IDfaltax) throws Exception, BDException, SQLException {
    try {
        Connection con = cone.getConnection();
        ps = (PreparedStatement) con.prepareStatement("DELETE FROM inasistencias WHERE IDfaltax = ?");
        ps.setInt(1, IDfaltax);

        int filasAfectadas = ps.executeUpdate();

        if (filasAfectadas == 0) {
            throw new Exception("No se encontró ninguna licencia con ese ID para eliminar.");
        }

    } catch (Exception e) {
        System.out.println(e);
        throw new Exception("No se pudo eliminar la licencia.");
    }
}
}

