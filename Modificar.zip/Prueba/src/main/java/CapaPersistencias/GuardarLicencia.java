/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaPersistencias;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import CapaExepcion.BDException;
import CapaLogica.Docente;
import CapaLogica.Licencias;
import CapaLogica.Persona;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author Alumno
 */
public class GuardarLicencia {
    
    // Sentencia para guardar una licencia
    private static final String SQL_Guardar3=("INSERT INTO parcial.usuarios(CI,nombre,apellido) VALUES (?,?,?)");
    
    private static final String SQL_Guardar2 =( 
     "INSERT INTO parcial.docentes(CId, Materia, Grupo, Turno) VALUES (?,?,?,?)");
      
    private static final String SQL_Guardar = (
        "INSERT INTO parcial.licencias(CIL, FechaINI, FechaFIN, Motivo) VALUES (?,?,?,?)"
    );
  //Se hicieron tres metedos ya que todas estas tablas, estan vinculadas entre si y necesitan
  //De la una a la otra para obtener los datos (Solucion realtiva, todavia no se verifica)
    
    
    // Consulta simple por CI
   private static final String SQL_Consulta_Licencias = (
   "SELECT u.Nombre, u.Apellido, d.Turno, e.CursoE AS Curso, " +
   "l.FechaINI, l.FechaFIN, l.Motivo AS Licencia " +
    "FROM parcial.usuarios u " +
    "JOIN parcial.docentes d ON u.CI = d.CId " +
    "JOIN parcial.enseña e ON u.CI = e.CIE " +
    "JOIN parcial.licencias l ON u.CI = l.CI " +
    "WHERE d.Grupo = ?");
   
  private static final String SQL_Inicio = ( 
    "SELECT * FROM parcial.administradores A " +
    "INNER JOIN parcial.usuarios U ON A.CIa = U.CI " +
    "WHERE U.nombre = ? AND A.IDa = ?");

     
    // Atributos de conexión
    public Conexion cone = new Conexion();
    public PreparedStatement ps;
    public ResultSet rs;
    
    // Métodos para guardar una licencia
    public void guardarUS(Persona pers) throws Exception, SQLException {
        try {
            int resultado = 0;
            Connection con = cone.getConnection();
            ps = (PreparedStatement) con.prepareStatement(SQL_Guardar3);
            ps.setString(1, pers.getCI());
            ps.setString(2, pers.getNombre());
            ps.setString(3, pers.getApellido());
            
            resultado = ps.executeUpdate();
            
        } catch (SQLException e) {
            throw new Exception("Tuve un problemita con la base al guardar la licencia"+ e.getMessage());
        }
    }
    //Se le coloco a cada metodo la CI para que exista una relacion entre ellas (mas que nada para que
    //no de problemas en mysql)
    public void guardarDocente(Docente doc) throws Exception, SQLException {
        try {
            int resultado = 0;
            Connection con = cone.getConnection();
            ps = (PreparedStatement) con.prepareStatement(SQL_Guardar2);
            ps.setString(1, doc.getCI()); 
            ps.setString(2, doc.getMateria()); 
            ps.setString(3, doc.getGrupo()); 
            ps.setString(4, doc.getTurno());
          
            resultado = ps.executeUpdate();
            
        } catch (SQLException e) {
            throw new Exception("Tuve un problemita con la base al guardar la licencia"+ e.getMessage());
        }
    }
    public void guardarLicencia(Licencias lic) throws Exception, SQLException {
        try {
            int resultado = 0;
            Connection con = cone.getConnection();
            ps = (PreparedStatement) con.prepareStatement(SQL_Guardar);
            ps.setString(1, lic.getCI());
            
            String fechaStr = lic.getFechaINI();
            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate fecha = LocalDate.parse(fechaStr, formato);
            ps.setDate(2, java.sql.Date.valueOf(fecha));
          
            //Se convirtieron las fechas puestas en string, como dates, CONSULTAR porque puede dar 
            //problemas que sean diferentes tipos de variables con respecto a la capa logica
            //y lo que esta puesto en la tabla de docentes en mysql
            
            String fechaStr2 = lic.getFechaFIN();
            DateTimeFormatter formato2 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate fecha2 = LocalDate.parse(fechaStr2, formato2);
            ps.setDate(3, java.sql.Date.valueOf(fecha2));
            
            //Se realizo el mismo proceso que antes
            
            ps.setString(4, lic.getMotivo());
            
            resultado = ps.executeUpdate();
            
        } catch (SQLException e) {
            throw new Exception("Tuve un problemita con la base al guardar la licencia"+ e.getMessage());
        }
    }
    
//    Método para buscar una licencia por CI
  public Licencias buscarCI(String CI) throws Exception, BDException, SQLException {
      Licencias lic=new Licencias();
        try {
            Connection con = cone.getConnection();
            ps = (PreparedStatement) con.prepareStatement(SQL_Consulta_Licencias);          
            ps.setString(1, CI);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                String ci = rs.getString("CI");
                String fechaIni = rs.getString("FechaINI");
                String fechaFin = rs.getString("FechaFIN");
                String motivo = rs.getString("Motivo");
                
                lic.setCI(ci);
                lic.setFechaINI(fechaIni);
                lic.setFechaFIN(fechaFin);
                lic.setMotivo(motivo);
            } else {
                throw new Exception("La licencia no está ingresada");
            }
          
       } catch (Exception e) {
         System.out.println(e);
         throw new Exception("No pude obtener la licencia");
       }
       return lic;
 }
  public boolean iniciaSesion(String nombre, String IDa) throws Exception{
        boolean valido=false;
        Docente doc = new Docente();
        Persona per = new Persona();
        Licencias lic = new Licencias();
        try{
            Connection con=cone.getConnection();
             ps=con.prepareStatement(SQL_Inicio);
            ps.setString(1,nombre);
            ps.setString(2,IDa);
            rs= ps.executeQuery();
            if(rs.next()){
                valido=true;
            }
            con.close();
        } catch(SQLException e){
            throw new Exception("Error al iniciar sesion " + e.getMessage());
            }
        return valido;
    }
}

