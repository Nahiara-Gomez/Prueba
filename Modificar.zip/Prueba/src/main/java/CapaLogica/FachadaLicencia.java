/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaLogica;

import CapaExepcion.BDException;
import CapaPersistencias.GuardarLicencia;
import java.sql.SQLException;
/**
 *
 * @author DELL
 */
public class FachadaLicencia {  
    public void guardarUS(Persona pers)throws Exception{
        GuardarLicencia gus= new GuardarLicencia();
       gus.guardarUS(pers);
    } 
    
    //Al igual que en la capa guardar licencia se agrego otra fachada guardarUS, ya que
    //se realizo otro metodo más
    public void guardarDocente(Docente doc)throws Exception{
        GuardarLicencia gdoc= new GuardarLicencia();
       gdoc.guardarDocente(doc);
    } 
    public void guardarLicencias(Licencias lic)throws Exception{
        GuardarLicencia gua= new GuardarLicencia();
       gua.guardarLicencia(lic);
    }
   public Persona  buscarporCi(String CI) throws  Exception, BDException,SQLException{
       Licencias lic = new Licencias();
       GuardarLicencia lice= new GuardarLicencia();
       lic=lice.buscarCI(CI);
       return lic;
   }
 
   public boolean iniciarSesion(String nombre, String IDa) throws Exception{
        GuardarLicencia pers= new GuardarLicencia();
        return  pers.iniciaSesion(nombre,IDa);
    }
}
