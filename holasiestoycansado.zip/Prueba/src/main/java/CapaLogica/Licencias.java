/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaLogica;

/**
 *
 * @author nahue
 */
public class Licencias extends Docente {
    private String IDfaltax;
    private String FechaIniX;
    private String FechaFinX;
    private String Motivox;
    

 

    public String getMotivo() {
        return Motivox;
    }

    public void setMotivo(String Motivox) {
        this.Motivox = Motivox;
    }
public void mostrarLicencia() {
    System.out.print("Fecha de Inicio"+ FechaIniX);
    System.out.print("Fecha de Finalizacion"+ FechaFinX);
    System.out.print("Motivo de la Licencia"+ Motivox);
}

    public String getFechaINI() {
        return FechaIniX;
    }

    public void setFechaINI(String FechaIniX) {
        this.FechaIniX = FechaIniX;
    }

    public String getFechaFin() {
        return FechaFinX;
    }

    public void setFechaFin(String FechaFinX) {
        this.FechaFinX = FechaFinX;
    }

    public String getIDfaltax() {
        return IDfaltax;
    }

    public void setIDfaltax(String iDfaltax) {
        IDfaltax = iDfaltax;
    }

  
    
}