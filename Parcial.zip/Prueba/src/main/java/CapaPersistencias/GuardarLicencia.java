/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaPersistencias;

import CapaExepcion.BDException;
import CapaLogica.Licencias;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Alumno
 */
public class GuardarLicencia {
    
    // Sentencia para guardar una licencia
    private static final String SQL_Guardar = (
        "INSERT INTO parcial.licencias(CI, FechaINI, FechaFIN, Motivo) VALUES (?,?,?,?)"
    );
    
    // Consulta simple por CI
    private static final String SQL_Consulta_Licencias = (
    "SELECT u.Nombre, u.Apellido, d.Turno, e.CursoE AS Curso, " +
    "l.FechaINI, l.FechaFIN, l.Motivo AS Licencia " +
    "FROM parcial.usuarios u " +
    "JOIN parcial.docentes d ON u.CI = d.CId " +
    "JOIN parcial.enseña e ON u.CI = e.CIE " +
    "JOIN parcial.licencias l ON u.CI = l.CI " +
    "WHERE d.Grupo = ?"
                                                );

    
    // Atributos de conexión
    public Conexion cone = new Conexion();
    public PreparedStatement ps;
    public ResultSet rs;
    
    // Método para guardar una licencia
    public void guardarLicencia(Licencias lic) throws Exception, SQLException {
        try {
            int resultado = 0;
            Connection con = cone.getConnection();
            ps = (PreparedStatement) con.prepareStatement(SQL_Guardar);
            ps.setString(1, lic.getCI());
            ps.setString(2, lic.getFecha_ini()); // fechas como String
            ps.setString(3, lic.getFecha_fin());
            ps.setString(4, lic.getMotivo());
            
            resultado = ps.executeUpdate();
            
        } catch (SQLException e) {
            throw new Exception("Tuve un problemita con la base al guardar la licencia");
        }
    }
    
    // Método para buscar una licencia por CI
    public Licencias SQL_Consulta_Licencias(String CI) throws Exception, BDException, SQLException {
        Licencias lic = new Licencias();
        try {
            Connection con = cone.getConnection();
            ps = (PreparedStatement) con.prepareStatement(SQL_Consulta_Licencias);
            ps.setString(1, CI);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                String ci = rs.getString("CI");
                String fechaIni = rs.getString("FechaINI");
                String fechaFin = rs.getString("FechaFIN");
                String motivo = rs.getString("Motivo");
                
                lic.setCI(ci);
                lic.setFecha_ini(fechaIni);
                lic.setFecha_fin(fechaFin);
                lic.setMotivo(motivo);
            } else {
                throw new Exception("La licencia no está ingresada");
            }
            
        } catch (Exception e) {
            System.out.println(e);
            throw new Exception("No pude obtener la licencia");
        }
        return lic;
    }
}
